module.exports = {
    'server': {
        'port': '8080',
        'host': 'localhost'
    },
    'helloWorld_service': {
        'port': '9001',
        'host': 'hello-world-service'
    },
    'product_descp_service': {
        'port': '9002',
        'host': 'product-descp-service'
    },
    'product_price_service': {
        'port': '9003',
        'host': 'product-price-service'
    }
};